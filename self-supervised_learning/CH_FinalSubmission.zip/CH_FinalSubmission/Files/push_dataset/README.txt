Data Explanation
train and test each contains 70k push(slightly more than 70k).
The txt documents the specifics of a push: (each row represents one push)
row entry   (world frame coordinates)
        0   push index
        1   start_push_x
        2   start_push_y
        3   end_push_x
        4   end_push_ys
        5   obj_x before push
        6.  obj_y before push